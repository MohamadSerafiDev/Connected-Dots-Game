class MoveResult {
  final bool success;
  final String message;

  MoveResult({required this.success, this.message = ''});
}
